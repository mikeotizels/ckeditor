/*
  CKEditor 4: 
  Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
  For licensing, see LICENSE.md or http://ckeditor.com/license
  
  Modified by Mikeotizels - Michael Otieno for development use. 
    This is a sample CKEditor configuration script. 
    You can edit it to suit your needs.
    For a sample text editor using this configuration, see index.html
*/


CKEDITOR.editorConfig = function( config ) {

	// Set the editor default language:
    /* Note: You may see strange characters if your system does not support the selected language */
	config.language = 'en'; 

	// Set the editor default ui color:
	config.uiColor = '#27c0d8';

	// Set the editor default height:
	config.height = 300;

	// Set the editor default width:
	config.width = 'auto';

	// Set the toolbar collapse true or false:
	config.toolbarCanCollapse = true;
};
