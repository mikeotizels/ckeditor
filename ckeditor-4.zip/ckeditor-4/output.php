<?php

/* <body><pre>

-------------------------------------------------------------------------------------------
  CKEditor - Output
  
  Sorry, your Web Server does not support the PHP language used in this script.

  Please not that this script needs to read the POST data from the Editor in order to 
  display the HTML text.

  You need a PHP enabled Web Server like <a href="http://apachefriends.org">Apache</a> to run this script.

  Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
  For licensing, see LICENSE.md or <a href="http://ckeditor.com/license">http://ckeditor.com/license</a>

  Modified by Mikeotizels - Michael Otieno for development use. 
  <a href="http://www.mikeotizels.orgfree.com?r=sorry">(http://www.mikeotizels.orgfree.com)</a> 
-------------------------------------------------------------------------------------------

</pre><div style="display:none"></body> */

?>
<!DOCTYPE html>
<html encoding="UTF-8" lang="en" dir="ltr">
<head>     
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta http-equiv="Content-type" content="text/html" />
  <meta http-equiv="Content-language" content="en-US" />
  <meta name="MobileOptimized" content="width" />
  <meta name="HandheldFriendly" content="true" />
  <meta name="apple-touch-fullscreen" content="yes" />
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="black" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />   
  <meta name="robots" content="index, follow" />
  <meta name="author" content="Mikeotizels <mikeotizels@gmail.com>" />
  <meta name="keywords" content="" />  
  <meta name="description" content="You can edit, preview, copy and save the HTML output for inputed text here." />

	<title>CKEditor &ndash; Output</title>

  <link rel="icon" type="image/png" href="img/favicon.png" />
  <link rel="shortcut icon" type="image/png" href="img/favicon.png" />
  <link rel="apple-touch-icon" type="image/png" href="img/favicon.png" />
  <link rel="stylesheet" type="text/css" href="css/output.css">
</head>  
<body>

<main>
	<h1>
		<a href="index.html" title="Back to Editor">CKEditor</a> &raquo; <font color="black">Output</font> 
	</h1>


<?php
  if (!empty($_POST)) {
  foreach ( $_POST as $key => $value ) {
    if ( ( !is_string($value) && !is_numeric($value) ) || !is_string($key) )
      continue;
    if ( get_magic_quotes_gpc() )
      $value = htmlspecialchars_decode(stripslashes((string)$value) );
    else
      $value = htmlspecialchars_decode( (string)$value );
?>

<textarea class="textarea" id="textarea">
<!DOCTYPE html>
<html encoding="UTF-8" lang="en" dir="ltr">
<head>     
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta http-equiv="Content-type" content="text/html" />
  <meta http-equiv="Content-language" content="en-US" />
  <meta name="MobileOptimized" content="width" />
  <meta name="HandheldFriendly" content="true" />
  <meta name="apple-touch-fullscreen" content="yes" />
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="black" />
  <meta name="viewport" content="width=device-width, initial-scale=1" /> 
  <meta name="robots" content="index, follow" />
  <meta name="author" content="Mikeotizels <mikeotizels@gmail.com>" />
  <meta name="keywords" content=""/>
  <meta name="description" content=""/>

  <title>Page Title</title>

  <link rel="icon" type="image/png" href="favicon.png" />
  <link rel="shortcut icon" type="image/png" href="favicon.png" />
  <link rel="apple-touch-icon" type="image/png" href="favicon.png" /> 

  <link rel="stylesheet" type="text/css" href=""/>
  <link rel="stylesheet" type="text/css" href=""/>
  <link rel="stylesheet" type="text/css" href=""/>
  <link rel="stylesheet" type="text/css" href=""/>
</head>
<body>

<?php
  if ($value == '') {
    print_r("<p>The plain text you enter on the editor textarea will be posted here as html text.</p>");
  } else {
    print_r($value);
  }
?>


  <script type="text/javascript" src=""></script>  
  <script type="text/javascript" src=""></script>
  <script type="text/javascript" src=""></script>
  <script type="text/javascript" src=""></script>

</body>
</html>
</textarea>

<?php } } ?>

  
    <br/>  
    <br/>      
      <button class="btn btn-reload" accesskey="r" onclick="javascript:window.location.reload();" title="Reload (Alt+R)">
        Reload
      </button>
	    <button class="btn btn-copy" accesskey="c" onclick="copyTextToClipboard();" title="Copy (Alt+C)">
        Copy
      </button>
      <button class="btn btn-save" accesskey="s" onclick="saveTextAsFile();" title="Save (Alt+S)">
        Save
      </button>
    <br/> 
    <br/>

</main>

<hr/>

<footer>
  <p>
    CKEditor &ndash; The text editor for the Internet (<a onclick="javascript:window.open('http://ckeditor.com/');" title="Open link in new tab">http://ckeditor.com</a>)
    <br/>
    Copyright &copy; 2003-2016, <a onclick="javascript:window.open('http://cksource.com/');" title="Open link in new tab">CKSource</a> &ndash; Frederico Knabben. All rights reserved.
    <br>
    Modified by <a onclick="javascript:window.open('http://mikeotizels.orgfree.com?s=ckeditor&r=output-footer');" title="Open link in new tab">Mikeotizels</a> for development use.
  </p>
</footer>


  <script type="text/javascript">
  // Saving the text as a file
    function saveTextAsFile() {
      var textToWrite = document.getElementById('textarea').innerHTML;
      var textFileAsBlob = new Blob([ textToWrite ], { type: 'text/html' });
      var fileNameToSaveAs = "ckeditor-output.html";

      var downloadLink = document.createElement("a");
      downloadLink.download = fileNameToSaveAs;
      downloadLink.innerHTML = "Download";
        
        if (window.webkitURL != null) {
          /* Chrome allows the link to be clicked without actually adding it to the DOM. */
          downloadLink.href = window.webkitURL.createObjectURL(textFileAsBlob);
        } else {
          /* Firefox requires the link to be added to the DOM before it can be clicked. */
          downloadLink.href = window.URL.createObjectURL(textFileAsBlob);
          downloadLink.onclick = destroyClickedElement;
          downloadLink.style.display = "none";
          document.body.appendChild(downloadLink);
      }

      downloadLink.click();
    }
      
      /* Save the text as a file on click of the save button */
      var button = document.getElementById('save');
        button.addEventListener('click', saveTextAsFile);
    
      /* Remove the link from the DOM */
      function destroyClickedElement(event) {
        document.body.removeChild(event.target);
    }
  </script>

  <script type="text/javascript">
  // Copying the text to clipboard
    function copyTextToClipboard() {

      /* Get the textarea field */
      var textareaText = document.getElementById("textarea");
       
      /* Select the textarea field */
      textareaText.select();

      /* Copy the text inside the textarea field */
      document.execCommand("copy");

      /* Alert the textarea has been copied */
      alert('The text has been copied.');
    }
  </script>

  <!-- Detecting unsaved changes -->
  <script type="text/javascript">
  // Alert unsaved work on exit if the textarea is not reset
    window.onbeforeunload = function(){
      var textarea = document.getElementById("textarea");
        if(textarea.value != ""){
          return "If you made any changes, please copy or save your text first.";
        }
    }
  </script>
    
</body>
</html>